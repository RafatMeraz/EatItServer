package com.practise.eatitserver.utils;

import com.practise.eatitserver.model.User;

public class Common {
    public static User currentUser;
}
